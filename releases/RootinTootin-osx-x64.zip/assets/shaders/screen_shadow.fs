#version 330

// Input vertex attributes
in vec2 fragTexCoord;
in vec4 fragColor;

// Output fragment color
out vec4 finalColor;

// Samplers
uniform sampler2D texture0;    // Diffuse rendered scene texture
uniform sampler2D shadowMask;  // 1-bit / silhouette mask (1.0 = solid blocker, 0.0 = open floor)
uniform sampler2D surfaceMap;       // Encoded raised-surface normal, height, and kind mask

// Dynamic lights (up to 20)
const int MAX_LIGHTS = 20;
uniform int lightCount;
uniform vec2 lightPositions[MAX_LIGHTS];     // Normalized screen coords matching fragTexCoord space
uniform vec3 lightColors[MAX_LIGHTS];        // RGB colors [0.0, 1.0]
uniform float lightIntensities[MAX_LIGHTS];  // Brightness multipliers
uniform float lightRadii[MAX_LIGHTS];        // Radius in normalized screen height units
uniform float lightElevations[MAX_LIGHTS];   // Height above the ground in normalized screen height units
uniform int lightCastsShadows[MAX_LIGHTS];   // 1 = raymarch shadows, 0 = radial illumination only

// Player line-of-sight shadow gating
uniform int hasPlayerLight;                  // 1 = gate dynamic lights by player LOS shadow mask
uniform vec2 playerLightPos;                 // Normalized screen coords of the player
uniform float playerLightElevation;          // Height of the player light in normalized screen height units

// Scene lighting parameters
uniform float aspectRatio;                   // screenWidth / screenHeight
uniform vec3 ambientColor;                   // Normalized RGB ambient dark color
uniform float surfaceHeightScale;             // Maximum world height in normalized screen height units
uniform float pillarRadius;                   // Pillar footprint radius in normalized screen height units

const int MAX_PLAYER_SHADOW_STEPS = 40;
const int MIN_LIGHT_SHADOW_STEPS = 16;
const int MAX_LIGHT_SHADOW_STEPS = 32;

float raymarchShadow(
    vec2 groundFragCoord,
    float surfaceHeight,
    bool hasRaisedSurface,
    bool isPillarSurface,
    bool isWallSurface,
    float selfMask,
    vec2 texSize,
    vec2 texelSize,
    float jitter,
    vec2 targetLightPos,
    float targetLightHeight,
    int maxSteps)
{
    vec2 rayDelta = targetLightPos - groundFragCoord;
    vec2 rayPixelDelta = rayDelta * texSize;
    float rayPixelDist = length(rayPixelDelta);

    if (rayPixelDist <= 1.0)
    {
        return 1.0;
    }

    vec2 rayPixelDir = rayPixelDelta / rayPixelDist;
    vec2 rayUvDir = rayPixelDir * texelSize;

    // Physical offset in pixels: fixed at 1.5px for walls to catch bevel rim, 0.5px for open floor.
    // This ensures distant lights never bleed deeply into obstacles.
    float startPixels = isPillarSurface
        ? max(1.5, pillarRadius * texSize.y * 2.0)
        : (isWallSurface || selfMask > 0.5 ? 1.5 : 0.5);

    // Immediate self-shadowing if fragment is deep inside an obstacle
    if (!hasRaisedSurface && selfMask > 0.5)
    {
        vec2 initialProbe = groundFragCoord + rayUvDir * startPixels;
        if (texture(shadowMask, initialProbe).r > 0.5)
        {
            return 0.0;
        }
    }

    float remainingDist = max(0.0, rayPixelDist - startPixels - 1.5);
    if (remainingDist <= 0.0)
    {
        return 1.0;
    }

    int stepBudget = clamp(maxSteps, MIN_LIGHT_SHADOW_STEPS, MAX_PLAYER_SHADOW_STEPS);
    float stepPixels = clamp(remainingDist / float(stepBudget), 3.0, 8.0);
    int stepCount = clamp(int(ceil(remainingDist / stepPixels)), 1, stepBudget);
    stepPixels = remainingDist / float(stepCount);

    float shadow = 1.0;
    for (int s = 0; s < stepCount; s++)
    {
        float curDist = startPixels + (float(s) + jitter) * stepPixels;
        if (curDist >= rayPixelDist - 0.5) break;

        vec2 sampleUv = groundFragCoord + rayUvDir * curDist;
        vec4 occluder = texture(shadowMask, sampleUv);
        float occ = occluder.r;

        float rayHeight = mix(surfaceHeight, targetLightHeight, curDist / rayPixelDist);
        float occluderHeight = occluder.g * surfaceHeightScale;
        if (occ > 0.05 && rayHeight < occluderHeight)
        {
            if (occ > 0.5)
            {
                shadow = 0.0;
                break;
            }

            // Soft penumbra only applies when the 3D ray intersects the occluder height.
            shadow *= clamp(1.0 - occ, 0.0, 1.0);
            if (shadow <= 0.05)
            {
                shadow = 0.0;
                break;
            }
        }
    }

    return shadow;
}

void main()
{
    vec4 sceneColor = texture(texture0, fragTexCoord);
    vec2 aspectScale = vec2(aspectRatio, 1.0);
    vec4 surfaceInfo = texture(surfaceMap, fragTexCoord);
    bool hasRaisedSurface = surfaceInfo.a > 0.5;
    // Undo filtering against the transparent map background before decoding its packed data.
    vec3 surfaceData = surfaceInfo.rgb / max(surfaceInfo.a, 0.0001);
    float packedSurfaceHeight = floor(surfaceData.b * 255.0 + 0.5);
    // Wall surface heights occupy the upper half of blue; pillar/cylinder/crate heights use the lower half.
    bool isWallSurface = hasRaisedSurface && packedSurfaceHeight >= 128.0;
    bool isPillarSurface = hasRaisedSurface && !isWallSurface;
    float heightStep = packedSurfaceHeight - (isWallSurface ? 128.0 : 0.0);
    float surfaceHeight = hasRaisedSurface ? (heightStep / 127.0) * surfaceHeightScale : 0.0;
    vec2 groundFragCoord = fragTexCoord - vec2(0.0, surfaceHeight);

    // Dimensions of the shadow mask texture in screen pixels
    vec2 texSize = vec2(textureSize(shadowMask, 0));
    vec2 texelSize = 1.0 / texSize;

    // Check if the current pixel itself is inside a blocker
    float selfMask = hasRaisedSurface ? 0.0 : texture(shadowMask, groundFragCoord).r;

    // Interleaved gradient noise for sub-pixel anti-aliasing along shadow boundaries
    float jitter = fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715))));

    // 1. Player line-of-sight shadow check and early-out for occluded regions
    float playerShadow = 1.0;
    if (hasPlayerLight != 0)
    {
        playerShadow = raymarchShadow(
            groundFragCoord,
            surfaceHeight,
            hasRaisedSurface,
            isPillarSurface,
            isWallSurface,
            selfMask,
            texSize,
            texelSize,
            jitter,
            playerLightPos,
            playerLightElevation,
            MAX_PLAYER_SHADOW_STEPS);

        if (playerShadow <= 0.0)
        {
            finalColor = vec4(sceneColor.rgb * ambientColor, sceneColor.a);
            return;
        }
    }

    // 2. Lazy normal decoding: only decode raised-surface normals for player-visible pixels
    vec3 surfaceNormal = vec3(0.0, 0.0, 1.0);
    if (hasRaisedSurface)
    {
        vec2 encodedNormal = surfaceData.rg * 2.0 - 1.0;
        float normalZ = sqrt(max(0.0, 1.0 - dot(encodedNormal, encodedNormal)));
        surfaceNormal = normalize(vec3(encodedNormal, normalZ));
    }

    vec2 fragPosAspect = groundFragCoord * aspectScale;
    vec3 totalLight = vec3(0.0);

    // 3. Raymarch for each active light
    int count = clamp(lightCount, 0, MAX_LIGHTS);
    for (int i = 0; i < count; i++)
    {
        float radius = lightRadii[i];
        if (radius <= 0.0001)
        {
            continue;
        }

        vec2 lightPos = lightPositions[i];
        vec2 toLightAspect = lightPos * aspectScale - fragPosAspect;
        float lightHeight = lightElevations[i];
        vec3 toLight = vec3(toLightAspect, lightHeight - surfaceHeight);

        // Squared-distance culling before sqrt()
        float distSq = dot(toLight, toLight);
        float radiusSq = radius * radius;
        if (distSq >= radiusSq || distSq <= 0.00000001)
        {
            continue;
        }

        float dist = sqrt(distSq);

        // Smooth radial attenuation with cubic ease-out
        float normDist = clamp(dist / radius, 0.0, 1.0);
        float remaining = 1.0 - normDist;
        float falloff = remaining * remaining * (3.0 - 2.0 * remaining);

        float diffuse = 1.0;
        if (hasRaisedSurface)
        {
            float ndotl = dot(surfaceNormal, toLight / dist);
            diffuse = surfaceNormal.z > 0.9 && ndotl <= 0.0
                ? max(0.0, 0.15 * (1.0 + ndotl))
                : max(0.0, ndotl);
            if (diffuse <= 0.0) continue;
        }

        float unshadowedWeight = falloff * lightIntensities[i] * diffuse;
        if (unshadowedWeight * playerShadow <= 0.001)
        {
            continue;
        }

        if (lightCastsShadows[i] == 0)
        {
            totalLight += lightColors[i] * (unshadowedWeight * playerShadow);
            continue;
        }

        // Reuse the precomputed playerShadow when this light is at the player's position & elevation
        vec2 playerDelta = lightPos - playerLightPos;
        bool isPlayerLight = hasPlayerLight != 0 &&
                             dot(playerDelta, playerDelta) < 0.000001 &&
                             abs(lightHeight - playerLightElevation) < 0.001;

        int lightMaxSteps = clamp(int(ceil(radius * 48.0)), MIN_LIGHT_SHADOW_STEPS, MAX_LIGHT_SHADOW_STEPS);
        float shadow = isPlayerLight
            ? playerShadow
            : raymarchShadow(
                groundFragCoord,
                surfaceHeight,
                hasRaisedSurface,
                isPillarSurface,
                isWallSurface,
                selfMask,
                texSize,
                texelSize,
                jitter,
                lightPos,
                lightHeight,
                lightMaxSteps) * playerShadow;

        totalLight += lightColors[i] * (unshadowedWeight * shadow);
    }

    // Multiply scene color by (ambient + accumulated illumination)
    vec3 litColor = sceneColor.rgb * (ambientColor + totalLight);
    finalColor = vec4(litColor, sceneColor.a);
}
